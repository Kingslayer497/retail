#!/usr/bin/env python
# coding: utf-8

# In[13]:


import pandas as pd
import numpy as np


# In[4]:


##任务3-1：给出每台售货机饮料类商品的标签
##因为由附件2可知，总共119类饮料类商品，所以接下来我用的判别标准就是那样商品的销量与平均销量之间的差距
##假如商品的销量超过平均销量的50%，则为畅销；同理，假如商品的销量不足平均销量的50%，则为滞销；其他的为正常

##因为只是对饮料类数据进行分析，所以我先对数据进行了处理，只留下了饮料类的数据
t1 = pd.read_csv('F:/数据/task3-1B.csv',encoding='gbk')
t2 = pd.read_csv('F:/数据/task3-1A.csv',encoding='gbk')
t3 = pd.read_csv('F:/数据/task3-1C.csv',encoding='gbk')
t4 = pd.read_csv('F:/数据/task3-1E.csv',encoding='gbk')
t5 = pd.read_csv('F:/数据/task3-1D.csv',encoding='gbk')

##售货机E43A6E078A04134各类饮料类商品的标签
##总销量为9023，所以平均销量为75瓶
def func1(x):
    if x>'112':
        return '畅销'
    if x<'37':
        return '滞销'
    else:
        return '正常'
    
t1['target'] = func1(t1['total'])
t1.to_csv('F:/泰迪云课堂Python学习/result/task3-1B.csv',sep = ',',index = False,encoding='gbk') 

##售货机E43A6E078A04172各类饮料类商品的标签
##总销量为6118，所以平均销量为51瓶
def func1(x):
    if x>'75':
        return '畅销'
    if x<'25':
        return '滞销'
    else:
        return '正常'
    
t2['target'] = func1(t2['total'])
t2.to_csv('F:/泰迪云课堂Python学习/result/task3-1A.csv',sep = ',',index = False,encoding='gbk') 

##售货机E43A6E078A04228各类饮料类商品的标签
##总销量为9805，所以平均销量为82瓶
def func1(x):
    if x>'123':
        return '畅销'
    if x<'41':
        return '滞销'
    else:
        return '正常'
    
t3['target'] = func1(t3['total'])
t3.to_csv('F:/泰迪云课堂Python学习/result/task3-1C.csv',sep = ',',index = False,encoding='gbk') 

##售货机E43A6E078A06874各类饮料类商品的标签
##总销量为15961，所以平均销量为134瓶
def func1(x):
    if x>'201':
        return '畅销'
    if x<'67':
        return '滞销'
    else:
        return '正常'
    
t4['target'] = func1(t4['total'])
t4.to_csv('F:/泰迪云课堂Python学习/result/task3-1E.csv',sep = ',',index = False,encoding='gbk') 

##售货机E43A6E078A07631各类饮料类商品的标签
##总销量为5509，所以平均销量为46瓶
def func1(x):
    if x>'69':
        return '畅销'
    if x<'23':
        return '滞销'
    else:
        return '正常'
    
t5['target'] = func1(t5['total'])
t5.to_csv('F:/泰迪云课堂Python学习/result/task3-1D.csv',sep = ',',index = False,encoding='gbk') 


# In[43]:


##任务3-2：生成完整的售货机画像

##售货机A的词云图
from wordcloud import WordCloud, STOPWORDS
from imageio import imread
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import csv
# 获取文章内容
with open("C:/Users/HP/Desktop/a.txt") as f:
    contents = f.read()
print("contents变量的类型：", type(contents))

# 使用jieba分词，获取词的列表
contents_cut = jieba.cut(contents)
print("contents_cut变量的类型：", type(contents_cut))
contents_list = " ".join(contents_cut)
print("contents_list变量的类型：", type(contents_list))

# 制作词云图，collocations避免词云图中词的重复，mask定义词云图的形状，图片要有背景色
wc = WordCloud(background_color="black", font_path=r"C:\Windows\Fonts\STFANGSO.ttf",width=400, height=300,max_words=100000)
wc.generate(contents_list)
wc.to_file("F:/泰迪云课堂Python学习/a.png")
image=wc.to_image()
image.show()

##售货机B的词云图
from wordcloud import WordCloud, STOPWORDS
from imageio import imread
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import csv
# 获取文章内容
with open("C:/Users/HP/Desktop/b.txt") as f:
    contents = f.read()
print("contents变量的类型：", type(contents))

# 使用jieba分词，获取词的列表
contents_cut = jieba.cut(contents)
print("contents_cut变量的类型：", type(contents_cut))
contents_list = " ".join(contents_cut)
print("contents_list变量的类型：", type(contents_list))

# 制作词云图，collocations避免词云图中词的重复，mask定义词云图的形状，图片要有背景色
wc = WordCloud(background_color="black", font_path=r"C:\Windows\Fonts\STFANGSO.ttf",width=400, height=300,max_words=100000)
wc.generate(contents_list)
wc.to_file("F:/泰迪云课堂Python学习/b.png")
image=wc.to_image()
image.show()

##售货机C的词云图
from wordcloud import WordCloud, STOPWORDS
from imageio import imread
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import csv
# 获取文章内容
with open("C:/Users/HP/Desktop/c.txt") as f:
    contents = f.read()
print("contents变量的类型：", type(contents))

# 使用jieba分词，获取词的列表
contents_cut = jieba.cut(contents)
print("contents_cut变量的类型：", type(contents_cut))
contents_list = " ".join(contents_cut)
print("contents_list变量的类型：", type(contents_list))

# 制作词云图，collocations避免词云图中词的重复，mask定义词云图的形状，图片要有背景色
wc = WordCloud(background_color="black", font_path=r"C:\Windows\Fonts\STFANGSO.ttf",width=400, height=300,max_words=100000)
wc.generate(contents_list)
wc.to_file("F:/泰迪云课堂Python学习/c.png")
image=wc.to_image()
image.show()

##售货机D的词云图
from wordcloud import WordCloud, STOPWORDS
from imageio import imread
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import csv
# 获取文章内容
with open("C:/Users/HP/Desktop/d.txt") as f:
    contents = f.read()
print("contents变量的类型：", type(contents))

# 使用jieba分词，获取词的列表
contents_cut = jieba.cut(contents)
print("contents_cut变量的类型：", type(contents_cut))
contents_list = " ".join(contents_cut)
print("contents_list变量的类型：", type(contents_list))

# 制作词云图，collocations避免词云图中词的重复，mask定义词云图的形状，图片要有背景色
wc = WordCloud(background_color="black", font_path=r"C:\Windows\Fonts\STFANGSO.ttf",width=400, height=300,max_words=100000)
wc.generate(contents_list)
wc.to_file("F:/泰迪云课堂Python学习/d.png")
image=wc.to_image()
image.show()

##售货机E的词云图
from wordcloud import WordCloud, STOPWORDS
from imageio import imread
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import csv
# 获取文章内容
with open("C:/Users/HP/Desktop/e.txt") as f:
    contents = f.read()
print("contents变量的类型：", type(contents))

# 使用jieba分词，获取词的列表
contents_cut = jieba.cut(contents)
print("contents_cut变量的类型：", type(contents_cut))
contents_list = " ".join(contents_cut)
print("contents_list变量的类型：", type(contents_list))

# 制作词云图，collocations避免词云图中词的重复，mask定义词云图的形状，图片要有背景色
wc = WordCloud(background_color="black", font_path=r"C:\Windows\Fonts\STFANGSO.ttf",width=400, height=300,max_words=100000)
wc.generate(contents_list)
wc.to_file("F:/泰迪云课堂Python学习/e.png")
image=wc.to_image()
image.show()


# In[ ]:





# In[ ]:




