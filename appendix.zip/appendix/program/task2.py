#!/usr/bin/env python
# coding: utf-8

# In[11]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# In[12]:


##任务2-1：绘制2017年6月销量前5的商品销量柱状图
##为了计算和绘制的方便，我先将数据按时间的升序排列，再将6月的数据提取出来,并保存为新的csv文件
detail = pd.read_csv('F:/泰迪云课堂Python学习/附件1.csv',encoding='gbk')
paytime = detail.paytime
print(detail.paytime.describe())
task1 = detail.iloc[11315:20355,:]
print(detail.iloc[11315,:])
print(detail.iloc[20354,:])
task1.to_csv('F:/泰迪云课堂Python学习/task2-1A.csv',sep = ',',index = False,encoding='gbk') 


# In[13]:


##计算出6月销量前5的商品，并得到它们的销量绘制柱状图
t1 = pd.read_csv('F:/泰迪云课堂Python学习/task2-1A.csv',encoding='gbk')
t1.a = t1.iloc[0:26,:]
print('100g*5瓶益力多在6月的订单量为：',t1.a['number'].count())
##其他商品的销量也可以通过这种方法算出，在此不一一列举了
##最后得出6月销量前5的商品为：怡宝纯净水销量有657，40g双汇玉米热狗肠销量有240，东鹏特饮销量有238，脉动销量有235，250ml维他柠檬茶销量有225

##绘制柱状图
plt.rcParams['font.sans-serif'] = 'SimHei'## 设置中文显示
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(10,10))
plt.title('2017年6月销量前5的商品销量柱状图')## 添加标题
plt.xlabel('商品名称')## 添加x轴的名称
plt.ylabel('销量')## 添加y轴的名称
plt.yticks([100,200,300,400,500,600,700])## 确定y轴刻度
label = ['怡宝纯净水','40g双汇玉米热狗肠','东鹏特饮','脉动','250ml维他柠檬茶']## 刻度标签
my_height = [657,240,238,235,225]
plt.xticks(range(5), label)
plt.bar(range(5), my_height, width = 0.5)## 绘制散点图

for i in range(len(my_height)):
    plt.text(i, my_height[i], my_height[i], va='bottom', ha='center') #在（i，my_height[i]）的位置显示数据（即高度）my_height[i]
    
plt.savefig('F:/泰迪云课堂Python学习/2017年6月销量前5的商品销量柱状图.png')
plt.show()


# In[14]:


t1 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1B.csv',encoding='gbk')
t2 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1A.csv',encoding='gbk')
t3 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1C.csv',encoding='gbk')
t4 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1E.csv',encoding='gbk')
t5 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1D.csv',encoding='gbk')


# In[5]:


##任务2-2：绘制每台售货机每月总交易额折线图及交易额月环比增长率柱状图
##以一台售货机E43A6E078A04134为例，其余的四台售货机都一样操作，就不在此一一展示了

##计算售货机E43A6E078A04134每个月的交易额
t1.month1 = t1.iloc[0:366,:]
print('售货机E43A6E078A04134在1月的交易额为：',t1.month1['payment'].sum())
t1.month2 = t1.iloc[366:551,:]
print('售货机E43A6E078A04134在2月的交易额为：',t1.month2['payment'].sum())
t1.month3 = t1.iloc[551:816,:]
print('售货机E43A6E078A04134在3月的交易额为：',t1.month3['payment'].sum())
t1.month4 = t1.iloc[816:1419,:]
print('售货机E43A6E078A04134在4月的交易额为：',t1.month4['payment'].sum())
t1.month5 = t1.iloc[1419:2288,:]
print('售货机E43A6E078A04134在5月的交易额为：',t1.month5['payment'].sum())
t1.month6 = t1.iloc[2288:4144,:]
print('售货机E43A6E078A04134在6月的交易额为：',t1.month6['payment'].sum())
t1.month7 = t1.iloc[4144:4489,:]
print('售货机E43A6E078A04134在7月的交易额为：',t1.month7['payment'].sum())
t1.month8 = t1.iloc[4489:5470,:]
print('售货机E43A6E078A04134在8月的交易额为：',t1.month8['payment'].sum())
t1.month9 = t1.iloc[5470:7215,:]
print('售货机E43A6E078A04134在9月的交易额为：',t1.month9['payment'].sum())
t1.month10 = t1.iloc[7215:9241,:]
print('售货机E43A6E078A04134在10月的交易额为：',t1.month10['payment'].sum())
t1.month11 = t1.iloc[9241:11272,:]
print('售货机E43A6E078A04134在11月的交易额为：',t1.month11['payment'].sum())
t1.month12 = t1.iloc[11272:13482,:]
print('售货机E43A6E078A04134在12月的交易额为：',t1.month12['payment'].sum())

##绘制售货机E43A6E078A04134每个月交易额的折线图
plt.rcParams['font.sans-serif'] = 'SimHei'## 设置中文显示
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(12,12))
plt.title('售货机E43A6E078A04134每个月交易额的折线图')## 添加标题
plt.xlabel('月份')## 添加x轴的名称
plt.ylabel('交易额')## 添加y轴的名称
plt.xticks([1,2,3,4,5,6,7,8,9,10,11,12])## 确定x轴刻度
plt.yticks([0,1000,2000,3000,4000,5000,6000,7000,8000,9000])## 确定y轴刻度
plt.plot([1,2,3,4,5,6,7,8,9,10,11,12],[1373.6, 602.3, 957.9, 2457.4, 3681.2, 7550.3, 1518.6, 3516.1, 7207.3, 8331.6, 8669.9, 8104.1],color = 'r',linestyle = '--')
plt.savefig('F:/泰迪云课堂Python学习/售货机E43A6E078A04134每个月交易额的折线图.png')
plt.show()


# In[6]:


##计算售货机E43A6E078A04134月交易额环比增长率，这里以1为增长1倍。-1为衰退到原来的1/2，0为持平
t1.month2.rate = (t1.month2['payment'].sum() - t1.month1['payment'].sum()) / t1.month1['payment'].sum()
print('售货机E43A6E078A04134在2月的环比增长率为：',t1.month2.rate)
t1.month3.rate = (t1.month3['payment'].sum() - t1.month2['payment'].sum()) / t1.month2['payment'].sum()
print('售货机E43A6E078A04134在3月的环比增长率为：',t1.month3.rate)
t1.month4.rate = (t1.month4['payment'].sum() - t1.month3['payment'].sum()) / t1.month3['payment'].sum()
print('售货机E43A6E078A04134在4月的环比增长率为：',t1.month4.rate)
t1.month5.rate = (t1.month5['payment'].sum() - t1.month4['payment'].sum()) / t1.month4['payment'].sum()
print('售货机E43A6E078A04134在5月的环比增长率为：',t1.month5.rate)
t1.month6.rate = (t1.month6['payment'].sum() - t1.month5['payment'].sum()) / t1.month5['payment'].sum()
print('售货机E43A6E078A04134在6月的环比增长率为：',t1.month6.rate)
t1.month7.rate = (t1.month7['payment'].sum() - t1.month6['payment'].sum()) / t1.month6['payment'].sum()
print('售货机E43A6E078A04134在7月的环比增长率为：',t1.month7.rate)
t1.month8.rate = (t1.month8['payment'].sum() - t1.month7['payment'].sum()) / t1.month7['payment'].sum()
print('售货机E43A6E078A04134在8月的环比增长率为：',t1.month8.rate)
t1.month9.rate = (t1.month9['payment'].sum() - t1.month8['payment'].sum()) / t1.month8['payment'].sum()
print('售货机E43A6E078A04134在9月的环比增长率为：',t1.month9.rate)
t1.month10.rate = (t1.month10['payment'].sum() - t1.month9['payment'].sum()) / t1.month9['payment'].sum()
print('售货机E43A6E078A04134在10月的环比增长率为：',t1.month10.rate)
t1.month11.rate = (t1.month11['payment'].sum() - t1.month10['payment'].sum()) / t1.month10['payment'].sum()
print('售货机E43A6E078A04134在11月的环比增长率为：',t1.month11.rate)
t1.month12.rate = (t1.month12['payment'].sum() - t1.month11['payment'].sum()) / t1.month11['payment'].sum()
print('售货机E43A6E078A04134在12月的环比增长率为：',t1.month12.rate)

##绘制售货机E43A6E078A04134交易额月环比增长率的柱状图
plt.rcParams['font.sans-serif'] = 'SimHei'## 设置中文显示
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(11,11))
plt.title('交易额月环比增长率图')## 添加标题
plt.xlabel('月份')## 添加x轴的名称
plt.ylabel('交易额月环比增长率')## 添加y轴的名称
plt.yticks([-1,-0.8,-0.6,-0.4,-0.2,0,0.2,0.4,0.6,0.8,1,1.2,1.4,1.6])## 确定y轴刻度
label = [2,3,4,5,6,7,8,9,10,11,12]## 刻度标签
my_height = [-0.5615171811298777,0.5904034534285243,1.565403486794028,0.49800602262553934,1.0510431381071388,-0.7988689191157966,1.3153562491768735,1.0497994937572876,0.15599461656931185,0.04060444572471087,-0.06526026828452473]
plt.xticks(range(11), label)
plt.bar(range(11), my_height, width = 0.5)## 绘制散点图

for i in range(len(my_height)):
    plt.text(i, my_height[i], my_height[i], va='bottom', ha='center') #在（i，my_height[i]）的位置显示数据（即高度）my_height[i]
    
plt.savefig('F:/泰迪云课堂Python学习/售货机E43A6E078A04134交易额月环比增长率柱状图.png')
plt.show()


# In[16]:


##任务2-3：绘制每台售货机毛利润占总毛利润比例的饼图（假设饮料类毛利率为0.25，非饮料类为0.2）
##首先我会分出每类商品的属性，然后将同属性的分在一起，接着计算它们的销售额，再根据它们的毛利率算出每类商品的毛利，把每台售货机的毛利算出来

t1 = pd.read_csv('F:/数据/task1-1B.csv',encoding='gbk')
t2 = pd.read_csv('F:/数据/task1-1A.csv',encoding='gbk')
t3 = pd.read_csv('F:/数据/task1-1C.csv',encoding='gbk')
t4 = pd.read_csv('F:/数据/task1-1E.csv',encoding='gbk')
t5 = pd.read_csv('F:/数据/task1-1D.csv',encoding='gbk')

t1.nodrink = t1.iloc[0:4450,:]
print('售货机E43A6E078A04134在非饮料类的交易额为：',t1.nodrink['payment'].sum())
t1.drink = t1.iloc[4450:13477,:]
print('售货机E43A6E078A04134在饮料类的交易额为：',t1.drink['payment'].sum())
t2.nodrink = t2.iloc[0:4362,:]
print('售货机E43A6E078A04172在非饮料类的交易额为：',t2.nodrink['payment'].sum())
t2.drink = t2.iloc[4362:10480,:]
print('售货机E43A6E078A04172在饮料类的交易额为：',t2.drink['payment'].sum())
t3.nodrink = t3.iloc[0:4683,:]
print('售货机E43A6E078A04228在非饮料类的交易额为：',t3.nodrink['payment'].sum())
t3.drink = t3.iloc[4683:14488,:]
print('售货机E43A6E078A04228在饮料类的交易额为：',t3.drink['payment'].sum())
t4.nodrink = t4.iloc[0:7539,:]
print('售货机E43A6E078A06874在非饮料类的交易额为：',t4.nodrink['payment'].sum())
t4.drink = t4.iloc[7539:23500,:]
print('售货机E43A6E078A06874在饮料类的交易额为：',t4.drink['payment'].sum())
t5.nodrink = t5.iloc[0:3201,:]
print('售货机E43A6E078A07631在非饮料类的交易额为：',t5.nodrink['payment'].sum())
t5.drink = t5.iloc[3201:8710,:]
print('售货机E43A6E078A07631在饮料类的交易额为：',t5.drink['payment'].sum())

print('售货机E43A6E078A04134在非饮料类的毛利为：',t1.nodrink['payment'].sum()/6)
print('售货机E43A6E078A04134在饮料类的毛利为：',t1.drink['payment'].sum()/5)
print('售货机E43A6E078A04172在非饮料类的毛利为：',t2.nodrink['payment'].sum()/6)
print('售货机E43A6E078A04172在饮料类的毛利为：',t2.drink['payment'].sum()/5)
print('售货机E43A6E078A04228在非饮料类的毛利为：',t3.nodrink['payment'].sum()/6)
print('售货机E43A6E078A04228在饮料类的毛利为：',t3.drink['payment'].sum()/5)
print('售货机E43A6E078A06874在非饮料类的毛利为：',t4.nodrink['payment'].sum()/6)
print('售货机E43A6E078A06874在饮料类的毛利为：',t4.drink['payment'].sum()/5)
print('售货机E43A6E078A07631在非饮料类的毛利为：',t5.nodrink['payment'].sum()/6)
print('售货机E43A6E078A07631在饮料类的毛利为：',t5.drink['payment'].sum()/5)

print('售货机E43A6E078A04134的总毛利为：',t1.nodrink['payment'].sum()/6+t1.drink['payment'].sum()/5)
print('售货机E43A6E078A04172的总毛利为：',t2.nodrink['payment'].sum()/6+t2.drink['payment'].sum()/5)
print('售货机E43A6E078A04228的总毛利为：',t3.nodrink['payment'].sum()/6+t3.drink['payment'].sum()/5)
print('售货机E43A6E078A06874的总毛利为：',t4.nodrink['payment'].sum()/6+t4.drink['payment'].sum()/5)
print('售货机E43A6E078A07631的总毛利为：',t5.nodrink['payment'].sum()/6+t5.drink['payment'].sum()/5)
print('所有售货机的总毛利为：',t1.nodrink['payment'].sum()/6+t1.drink['payment'].sum()/5+t2.nodrink['payment'].sum()/6+t2.drink['payment'].sum()/5+t3.nodrink['payment'].sum()/6+t3.drink['payment'].sum()/5+t4.nodrink['payment'].sum()/6+t4.drink['payment'].sum()/5+t5.nodrink['payment'].sum()/6+t5.drink['payment'].sum()/5)

##绘制每台售货机毛利润占总毛利润比例的饼图
plt.figure(figsize=(10,10))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['售货机E43A6E078A04134','售货机E43A6E078A04172','售货机E43A6E078A04228','售货机E43A6E078A06874','售货机E43A6E078A07631']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01,0.01,0.01]## 设定各项离心n个半径
plt.pie([10192.033333333333,7912.193333333333,11624.47,18111.766666666666,6225.286666666667], explode=explode, labels=label, autopct='%1.1f%%')## 绘制饼图,像这样设置explode就会有较明显的白条做分隔，没有设置的话就只有一条细细的黑线做分隔，后面的autopct是用来显示占比的，%1.1f%表示用百分数表示占比的浮点数，保留一位小数
plt.title('每台售货机毛利润占总毛利润比例')
plt.savefig('F:/泰迪云课堂Python学习/每台售货机毛利润占总毛利润比例饼图')
plt.show()


# In[8]:


##任务2-4：绘制每月交易额均值的气泡图，横轴为时间，纵轴为商品的二级类目


# In[23]:


##任务2-5：绘制售货机C6，7，8三个月订单量的热力图，横轴以天为单位，纵轴以小时为单位，从热力图可以分析得出什么结论？

import pandas as pd
import numpy as np

##6月热力图
ax1 = p.add_subplot(1,3,1)
aaa = pd.read_csv('F:/数据/task1-1A.csv',encoding='gbk')
aaa['支付时间'] = pd.to_datetime(aaa.iloc[:,6])
sss=[]
for j in range(1,31):
    month6 = aaa[(aaa['支付时间'].dt.day==j) & (aaa['支付时间'].dt.month==6) ]
    ss=[] 
    for i in range(0,24):
        dd=month6[month6['支付时间'].dt.hour==i]
        cc=dd.shape[0]
        ss.append(cc)
    sss.append(ss)
import matplotlib.pyplot as plt
x = np.arange(1,31)
y = np.arange(0,24)
height = 26
width = 31
arr = np.zeros((height, width))
for i in range(len(x)):
    for j in range(len(y)):
        arr[j, i] = sss[i][j]
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.matshow(arr, cmap='hot')
plt.colorbar()
plt.xlabel('天数')
plt.ylabel('小时数')
plt.title('6月热力图')
plt.savefig('F:/泰迪云课堂Python学习/售货机C在6月订单量的热力图.png')
plt.show()

##7月热力图
ax2 = p.add_subplot(1,3,2)
aaa['支付时间'] = pd.to_datetime(aaa.iloc[:,6])
sss=[]
for j in range(1,32):
    month7 = aaa[(aaa['支付时间'].dt.day==j) & (aaa['支付时间'].dt.month==7) ]
    ss=[] 
    for i in range(0,24):
        dd=month7[month7['支付时间'].dt.hour==i]
        cc=dd.shape[0]
        ss.append(cc)
    sss.append(ss)
import matplotlib.pyplot as plt
x = np.arange(1,32)
y = np.arange(0,24)
height = 26
width = 32
arr = np.zeros((height, width))
for i in range(len(x)):
    for j in range(len(y)):
        arr[j, i] = sss[i][j]
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.matshow(arr, cmap='hot')
plt.colorbar()
plt.xlabel('天数')
plt.ylabel('小时数')
plt.title('7月热力图')
plt.savefig('F:/泰迪云课堂Python学习/售货机C在7月订单量的热力图.png')
plt.show()

##8月热力图
ax3 = p.add_subplot(1,3,3)
aaa['支付时间'] = pd.to_datetime(aaa.iloc[:,6])
sss=[]
for j in range(1,32):
    month8 = aaa[(aaa['支付时间'].dt.day==j) & (aaa['支付时间'].dt.month==8) ]
    ss=[] 
    for i in range(0,24):
        dd=month8[month8['支付时间'].dt.hour==i]
        cc=dd.shape[0]
        ss.append(cc)
    sss.append(ss)
import matplotlib.pyplot as plt
x = np.arange(1,32)
y = np.arange(0,24)
height = 26
width = 32
arr = np.zeros((height, width))
for i in range(len(x)):
    for j in range(len(y)):
        arr[j, i] = sss[i][j]
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.matshow(arr, cmap='hot')
plt.colorbar()
plt.xlabel('天数')
plt.ylabel('小时数')
plt.title('8月热力图')
plt.savefig('F:/泰迪云课堂Python学习/售货机C在8月订单量的热力图.png')
plt.show()


# In[ ]:




