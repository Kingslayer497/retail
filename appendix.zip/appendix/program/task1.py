#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[3]:


##任务1.1：提取每台售货机对应的销售数据，保存在CSV文件中
detail = pd.read_csv('F:/泰迪云课堂Python学习/附件1.csv',encoding='gbk')
print('附件1的前五个为：','\n',detail.head())
order_id = detail.order_id
print(detail.order_id.describe())


# In[4]:


##我先将数据按order_id的升序从小到大再重新排了一次，再进行数据的分离,将每台售货机对应的销售数据分别保存为csv文件
task1 = detail.iloc[0:13482,:]
task2 = detail.iloc[13482:23968,:]
task3 = detail.iloc[23968:38462,:]
task4 = detail.iloc[38462:61967,:]
task5 = detail.iloc[61967:70680,:]
print(task1.order_id.describe())
print(task2.order_id.describe())
print(task3.order_id.describe())
print(task4.order_id.describe())
print(task5.order_id.describe())
import os
task1.to_csv('F:/泰迪云课堂Python学习/result/task1-1B.csv',sep = ',',index = False,encoding='gbk') 
task2.to_csv('F:/泰迪云课堂Python学习/result/task1-1A.csv',sep = ',',index = False,encoding='gbk') 
task3.to_csv('F:/泰迪云课堂Python学习/result/task1-1C.csv',sep = ',',index = False,encoding='gbk')
task4.to_csv('F:/泰迪云课堂Python学习/result/task1-1E.csv',sep = ',',index = False,encoding='gbk') 
task5.to_csv('F:/泰迪云课堂Python学习/result/task1-1D.csv',sep = ',',index = False,encoding='gbk') 


# In[5]:


##将每台售货机的数据保存到csv文件中
t1 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1B.csv',encoding='gbk')
t2 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1A.csv',encoding='gbk')
t3 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1C.csv',encoding='gbk')
t4 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1E.csv',encoding='gbk')
t5 = pd.read_csv('F:/泰迪云课堂Python学习/result/task1-1D.csv',encoding='gbk')


# In[7]:


##任务1.2：计算售货机E43A6E078A04134在5月的交易额和订单量
t1.month5 = t1.iloc[1419:2288,:]
print('售货机E43A6E078A04134在5月的交易额为：',t1.month5['payment'].sum())
print('售货机E43A6E078A04134在5月的订单量为：',t1.month5['number'].count())


# In[9]:


##计算售货机E43A6E078A04172在5月的交易额和订单量
t2.month5 = t2.iloc[1151:1907,:]
print('售货机E43A6E078A04172在5月的交易额为：',t2.month5['payment'].sum())
print('售货机E43A6E078A04172在5月的订单量为：',t2.month5['number'].count())


# In[11]:


##计算售货机E43A6E078A04228在5月的交易额和订单量
t3.month5 = t3.iloc[1583:2372,:]
print('售货机E43A6E078A04228在5月的交易额为：',t3.month5['payment'].sum())
print('售货机E43A6E078A04228在5月的订单量为：',t3.month5['number'].count())


# In[13]:


##计算售货机E43A6E078A06874在5月的交易额和订单量
t4.month5 = t4.iloc[1857:3149,:]
print('售货机E43A6E078A06874在5月的交易额为：',t4.month5['payment'].sum())
print('售货机E43A6E078A06874在5月的订单量为：',t4.month5['number'].count())


# In[15]:


##计算售货机E43A6E078A07631在5月的交易额和订单量
t5.month5 = t4.iloc[1035:1599,:]
print('售货机E43A6E078A07631在5月的交易额为：',t5.month5['payment'].sum())
print('售货机E43A6E078A07631在5月的订单量为：',t5.month5['number'].count())


# In[16]:


##所有售货机的交易总额和订单总量就是上面的各台售货机的交易总额和订单总量各自加起来的总和
##每台售货机的每月日均交易额与日均订单量都是像上面那样先算出整个月的交易额与订单量，再除以每个月的交易天数即可
##这两步的答案将在报告中以表格的形式呈现


# In[ ]:




